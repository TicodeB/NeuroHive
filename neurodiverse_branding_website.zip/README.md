# NeuroHive Website Documentation

## Project Overview and Purpose

NeuroHive is a comprehensive e-commerce platform specifically designed for adults with ADHD and caregivers of ADHD minors. The website serves as an all-in-one ecosystem for products, services, and resources spanning all 8 domains of ADHD management:

1. Executive Function
2. Attention Regulation
3. Emotional Regulation
4. Time Management
5. Impulse Control
6. Social Functioning
7. Work Performance
8. Hyperactivity

The platform aims to revolutionize ADHD management by providing the first comprehensive e-commerce solution that addresses the fragmented nature of current ADHD solutions. NeuroHive (rebranded from ADHDaptive) empowers users with specialized tools, resources, and professional services to improve quality of life and daily functioning.

## Site Structure and Navigation

### Main Pages

The NeuroHive website consists of the following main pages:

1. **Home (index.html)**: Introduction to the platform, featuring the 8 ADHD management domains, featured products, target personas, and service offerings.
2. **About Us (about.html)**: Information about the company's mission, vision, and team.
3. **Products (products.html)**: Comprehensive catalog of products organized by the 8 ADHD management domains.
4. **Services (services.html)**: Professional services including ADHD coaching, cognitive behavioral therapy, nutritional consultations, and group workshops.
5. **Resources (resources.html)**: Educational content, guides, and tools for ADHD management.
6. **Contact (contact.html)**: Contact information and inquiry form.

### Navigation Structure

The website features a user-friendly navigation system designed with ADHD users in mind:

- **Main Navigation**: Persistent top navigation bar with clear, concise labels
- **Dropdown Menus**: Organized product categories by ADHD domain
- **Mobile Navigation**: Collapsible menu for smaller screens with touch-friendly targets
- **Breadcrumbs**: Help users understand their location within the site
- **Search Functionality**: Accessible from any page via the search icon in the header

### Content Organization

Content is organized using a clear hierarchy and chunking strategy to reduce cognitive load:

- **Section Headers**: Clear visual distinction between content sections
- **Card-Based Layout**: Information presented in digestible, visually distinct cards
- **Progressive Disclosure**: Complex information revealed gradually to prevent overwhelm
- **Visual Hierarchy**: Important elements highlighted through size, color, and positioning

## Accessibility Features for Neurodiverse Users

NeuroHive implements comprehensive accessibility features specifically designed for neurodiverse users, particularly those with ADHD:

### Accessibility Control Panel

An accessible control panel allows users to customize their browsing experience:

- **Font Size Adjustment**: Increase or decrease text size for better readability
- **Color Mode Options**: 
  - Light mode (default)
  - Dark mode for reduced visual strain
  - High contrast mode for improved readability
- **Reduce Motion**: Disable animations and transitions for users sensitive to movement
- **Focus Mode**: Reduce visual distractions by dimming non-essential page elements

### ADHD-Specific Design Considerations

1. **Attention Management**:
   - Minimized visual clutter throughout the interface
   - Reduced unnecessary animations that could distract users
   - Clear visual hierarchy to guide attention
   - Strategic use of white space to reduce overwhelm

2. **Cognitive Load Reduction**:
   - Information chunking into manageable sections
   - Clear, concise language throughout
   - Consistent navigation patterns
   - Memory aids like breadcrumbs and progress indicators

3. **Focus Support**:
   - Enhanced focus states for interactive elements
   - Logical tab order for keyboard navigation
   - Focus mode to minimize distractions
   - Clear visual feedback for user interactions

4. **Color and Typography**:
   - Calming color palette featuring blues and greens
   - High contrast ratios exceeding WCAG AA standards
   - Sans-serif fonts with clear character differentiation
   - Consistent text alignment and adequate line spacing

### WCAG 2.2 Compliance

The website adheres to WCAG 2.2 guidelines with particular attention to criteria beneficial for neurodiverse users:

- **2.2.1 Timing Adjustable**: No time limits on forms or interactions
- **2.2.2 Pause, Stop, Hide**: Controls for any moving content
- **2.4.6 Headings and Labels**: Clear, descriptive headings and labels throughout
- **2.4.7 Focus Visible**: Enhanced focus indicators for keyboard navigation
- **3.2.3 Consistent Navigation**: Consistent navigation patterns across all pages
- **3.2.4 Consistent Identification**: Components with similar functionality identified consistently
- **3.3.5 Help**: Context-sensitive help and instructions provided where needed

## Design Choices and Research Alignment

### Color Scheme

The color palette was carefully selected to support users with ADHD:

- **Primary Color (Blue #3a7ca5)**: A calming blue that promotes focus and reduces anxiety
- **Secondary Color (Green #5d9e7e)**: A soft green that complements the primary color and creates a sense of balance
- **Accent Color (Orange #f39237)**: A warm orange used sparingly for call-to-action elements
- **Background Colors**: Soft, off-white backgrounds (#f9f9f9) rather than stark white to reduce visual strain
- **Text Colors**: Dark gray (#333333) rather than pure black for reduced contrast strain

This color scheme aligns with research showing that individuals with ADHD benefit from calming colors and reduced visual stimulation.

### Typography

Typography choices were made to enhance readability and reduce cognitive load:

- **Primary Font (Open Sans)**: A clean, highly readable sans-serif font for body text
- **Heading Font (Poppins)**: A distinctive sans-serif font for headings that creates clear visual hierarchy
- **Font Sizing**: Minimum 16px for body text with adequate scaling for headings
- **Line Spacing**: 1.6 times the font size for improved readability
- **Text Alignment**: Left-aligned text throughout for consistent reading patterns

### Layout and Structure

The layout was designed to support ADHD users' needs:

- **Clear Visual Hierarchy**: Important elements stand out through size, color, and positioning
- **Consistent Patterns**: Predictable layout patterns across all pages
- **White Space**: Strategic use of white space to reduce visual overwhelm
- **Content Chunking**: Information divided into manageable sections
- **Card-Based Design**: Content contained in distinct visual containers

### Interactive Elements

Interactive elements were designed for intuitive use:

- **Large Target Areas**: Buttons and interactive elements have generous sizing
- **Clear Visual Feedback**: Hover, focus, and active states are visually distinct
- **Consistent Behavior**: Interactive elements behave predictably across the site
- **Error Prevention**: Forms include validation and clear error messages
- **Forgiving Design**: Easy recovery from mistakes

### Inspiration from Diorama Website

The design draws inspiration from the Diorama website in several key ways:

1. **Clean, Modern Layout**: Ample white space and strategic content organization
2. **Sophisticated Color Palette**: Professional color scheme with strategic accent colors
3. **User-Centric Approach**: Intuitive navigation and seamless user journeys
4. **Visual Cohesion**: Consistent design language across all pages
5. **Strategic Design Philosophy**: Fusion of business objectives with design aesthetics

## Shopify Integration Instructions

NeuroHive is designed to be implemented on the Shopify e-commerce platform. Follow these instructions to set up the website on Shopify:

### 1. Shopify Account Setup

1. Create a Shopify account at [shopify.com](https://www.shopify.com)
2. Select an appropriate plan based on your business needs
3. Complete the initial store setup process

### 2. Theme Implementation

1. From your Shopify admin dashboard, navigate to "Online Store" > "Themes"
2. Click "Upload theme" and select the NeuroHive theme zip file
3. After uploading, click "Publish" to make it your active theme

### 3. Page Setup

1. Go to "Online Store" > "Pages" in your Shopify admin
2. Create the following pages:
   - About Us
   - Products (this will be your collection page)
   - Services
   - Resources
   - Contact
3. For each page, use the HTML content from the corresponding HTML files in this package

### 4. Navigation Setup

1. Go to "Online Store" > "Navigation" in your Shopify admin
2. Create a main menu with links to all main pages
3. Set up dropdown menus for the Products section, organized by ADHD domain

### 5. Product Configuration

1. Go to "Products" > "Collections" in your Shopify admin
2. Create collections for each ADHD domain:
   - Executive Function
   - Attention Regulation
   - Emotional Regulation
   - Time Management
   - Impulse Control
   - Social Functioning
   - Work Performance
   - Hyperactivity
3. Add products to each collection with appropriate tags, descriptions, and images

### 6. Accessibility Features Implementation

1. Ensure the script.js file is properly linked in your theme
2. Test all accessibility features to confirm they're working correctly
3. Consider adding the Shopify Accessibility app for additional features

### 7. Custom CSS and JavaScript

1. Go to "Online Store" > "Themes" > "Actions" > "Edit code"
2. Upload the style.css file to the Assets folder
3. Upload the script.js file to the Assets folder
4. Update theme.liquid to include references to these files

## Future Development Recommendations

Based on the business objectives and market analysis, we recommend the following future developments for the NeuroHive website:

### 1. Enhanced Personalization

- Implement a personalization engine that recommends products based on user preferences and ADHD profile
- Create personalized dashboards for registered users
- Develop a quiz/assessment tool to help users identify their specific ADHD management needs

### 2. Community Features

- Add a community forum for users to share experiences and tips
- Implement user reviews and ratings for products
- Create a blog with regular content updates about ADHD management
- Develop virtual events and webinar functionality

### 3. Mobile App Development

- Create a companion mobile app for on-the-go access
- Implement mobile-specific features like reminders and habit tracking
- Ensure seamless integration between the website and mobile app

### 4. Expanded E-commerce Capabilities

- Implement subscription services for regularly used products
- Develop bundled product offerings for specific ADHD needs
- Create a loyalty program to encourage repeat purchases
- Implement advanced filtering options for product discovery

### 5. International Expansion

- Add multilingual support for expansion into different European markets
- Implement region-specific pricing and shipping options
- Develop localized content for different markets
- Create country-specific subdomains or sections

### 6. Advanced Accessibility Features

- Implement text-to-speech functionality
- Add more customization options for user interface
- Develop specialized navigation modes for different user needs
- Create simplified versions of pages for users who prefer minimal distractions

### 7. Integration with ADHD Management Tools

- Develop integrations with popular calendar and task management apps
- Create APIs for third-party developers to build compatible tools
- Implement tracking and analytics for users to monitor their ADHD management progress

### 8. Professional Services Expansion

- Develop an online booking system for professional services
- Implement video consultation capabilities
- Create a professional directory for ADHD specialists
- Develop continuing education resources for professionals

These recommendations align with the business objectives outlined in the pitch deck and will help NeuroHive achieve its goal of becoming the leading comprehensive ADHD management platform in Europe.