# Domain Availability and Pricing Report

## Overview
This report compares the domain availability and pricing for two potential brand names:
1. NeuroHive
2. MindMosaic

Across the following TLDs:
- .com
- .sk (Slovakia)
- .cz (Czech Republic)
- .pl (Poland)
- .co.uk (United Kingdom)
- .ie (Ireland)

## Domain Availability Summary

| Brand | TLD | Domain | Availability | Pricing | Requirements |
|-------|-----|--------|-------------|---------|--------------|
| neurohive | .com | neurohive.com | Not Available | Not available for purchase | No specific requirements, globally available |
| neurohive | .sk | neurohive.sk | Potentially Available | Estimated: €15 - €25 per year (avg: €20) | No physical presence required, but local trustee services available for international registrants |
| neurohive | .cz | neurohive.cz | Potentially Available | Estimated: €10 - €20 per year (avg: €15) | No geographical restrictions, minimum registration period is one year |
| neurohive | .pl | neurohive.pl | Potentially Available | Estimated: €9 - €18 per year (avg: €13) | No residency requirements, can be registered by any individual or legal entity |
| neurohive | .co.uk | neurohive.co.uk | Not Available | Not available for purchase | Registrant name must contain at least 4 characters, at least 3 must be letters |
| neurohive | .ie | neurohive.ie | Potentially Available | Estimated: €20 - €35 per year (avg: €25) | Must demonstrate a genuine connection to Ireland, documentation required |
| mindmosaic | .com | mindmosaic.com | Not Available | Not available for purchase | No specific requirements, globally available |
| mindmosaic | .sk | mindmosaic.sk | Potentially Available | Estimated: €15 - €25 per year (avg: €20) | No physical presence required, but local trustee services available for international registrants |
| mindmosaic | .cz | mindmosaic.cz | Potentially Available | Estimated: €10 - €20 per year (avg: €15) | No geographical restrictions, minimum registration period is one year |
| mindmosaic | .pl | mindmosaic.pl | Potentially Available | Estimated: €9 - €18 per year (avg: €13) | No residency requirements, can be registered by any individual or legal entity |
| mindmosaic | .co.uk | mindmosaic.co.uk | Not Available | Not available for purchase | Registrant name must contain at least 4 characters, at least 3 must be letters |
| mindmosaic | .ie | mindmosaic.ie | Potentially Available | Estimated: €20 - €35 per year (avg: €25) | Must demonstrate a genuine connection to Ireland, documentation required |

## TLD Registration Requirements

### .com
No specific requirements, globally available

### .sk
No physical presence required, but local trustee services available for international registrants

### .cz
No geographical restrictions, minimum registration period is one year

### .pl
No residency requirements, can be registered by any individual or legal entity

### .co.uk
Registrant name must contain at least 4 characters, at least 3 must be letters

### .ie
Must demonstrate a genuine connection to Ireland, documentation required


## Budget Analysis

The budget constraint is 11 euros per month (or equivalent annual cost of 132 euros per year).

### Domains Within Budget

| Domain | Yearly Cost | Monthly Cost |
|--------|-------------|-------------|
| neurohive.sk | €20.0 | €1.67 |
| neurohive.cz | €15.0 | €1.25 |
| neurohive.pl | €13.0 | €1.08 |
| neurohive.ie | €25.0 | €2.08 |
| mindmosaic.sk | €20.0 | €1.67 |
| mindmosaic.cz | €15.0 | €1.25 |
| mindmosaic.pl | €13.0 | €1.08 |
| mindmosaic.ie | €25.0 | €2.08 |

## Recommendation

Based on the availability and pricing information gathered, here is the recommendation for which brand name has better domain availability:

Both **NeuroHive** and **MindMosaic** have similar domain availability across the specified TLDs with 4 potentially available domains each.

Both brands have a similar number of domain options within the budget constraint with 4 affordable domains each.

### Final Recommendation

Both brand names have similar domain availability and budget options. The final decision should be based on other branding factors beyond domain availability.

Consider these additional factors:
- Brand memorability and uniqueness
- Ease of pronunciation and spelling
- Relevance to your business or product
- Target audience preferences
- Long-term brand strategy


### Important Notes

- Domain availability can change rapidly as domains are registered and released daily
- Pricing may vary based on promotions, registrar policies, and currency fluctuations
- Some TLDs may have additional fees for privacy protection or other services
- It's recommended to verify this information directly with domain registrars before making a final decision
- For country-specific TLDs (.sk, .cz, .pl, .co.uk, .ie), check the specific registration requirements carefully

This report was generated on April 16, 2025, and reflects the domain availability status as of that date.