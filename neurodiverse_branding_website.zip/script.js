/**
 * NeuroHive - Main JavaScript
 * 
 * This script handles all interactive elements of the NeuroHive website,
 * with special focus on accessibility features for neurodiverse users.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initAccessibilityControls();
    initNavigation();
    initSearch();
    initProductInteractions();
    
    // Check for saved user preferences
    loadUserPreferences();
});

/**
 * Accessibility Controls
 * Handles all accessibility features and user preferences
 */
function initAccessibilityControls() {
    // Toggle accessibility panel
    const toggleButton = document.getElementById('toggleA11y');
    const accessibilityControls = document.querySelector('.accessibility-controls');
    
    if (toggleButton) {
        toggleButton.addEventListener('click', function() {
            accessibilityControls.classList.toggle('active');
            const isExpanded = accessibilityControls.classList.contains('active');
            toggleButton.setAttribute('aria-expanded', isExpanded);
        });
    }
    
    // Font size controls
    const increaseFontBtn = document.getElementById('increaseFontSize');
    const decreaseFontBtn = document.getElementById('decreaseFontSize');
    const resetFontBtn = document.getElementById('resetFontSize');
    
    if (increaseFontBtn && decreaseFontBtn && resetFontBtn) {
        // Get the current font size from the root element
        let currentFontSize = parseFloat(getComputedStyle(document.documentElement).fontSize);
        const originalFontSize = currentFontSize;
        
        increaseFontBtn.addEventListener('click', function() {
            currentFontSize *= 1.1; // Increase by 10%
            document.documentElement.style.fontSize = `${currentFontSize}px`;
            saveUserPreference('fontSize', currentFontSize);
            announceChange('Font size increased');
        });
        
        decreaseFontBtn.addEventListener('click', function() {
            currentFontSize *= 0.9; // Decrease by 10%
            document.documentElement.style.fontSize = `${currentFontSize}px`;
            saveUserPreference('fontSize', currentFontSize);
            announceChange('Font size decreased');
        });
        
        resetFontBtn.addEventListener('click', function() {
            currentFontSize = originalFontSize;
            document.documentElement.style.fontSize = `${currentFontSize}px`;
            saveUserPreference('fontSize', currentFontSize);
            announceChange('Font size reset to default');
        });
    }
    
    // Color mode controls
    const lightModeBtn = document.getElementById('lightMode');
    const darkModeBtn = document.getElementById('darkMode');
    const contrastModeBtn = document.getElementById('contrastMode');
    
    if (lightModeBtn && darkModeBtn && contrastModeBtn) {
        lightModeBtn.addEventListener('click', function() {
            document.body.classList.remove('dark-mode', 'high-contrast');
            saveUserPreference('colorMode', 'light');
            announceChange('Light mode activated');
        });
        
        darkModeBtn.addEventListener('click', function() {
            document.body.classList.add('dark-mode');
            document.body.classList.remove('high-contrast');
            saveUserPreference('colorMode', 'dark');
            announceChange('Dark mode activated');
        });
        
        contrastModeBtn.addEventListener('click', function() {
            document.body.classList.add('high-contrast');
            document.body.classList.remove('dark-mode');
            saveUserPreference('colorMode', 'high-contrast');
            announceChange('High contrast mode activated');
        });
    }
    
    // Reduce motion toggle
    const reduceMotionToggle = document.getElementById('reduceMotion');
    
    if (reduceMotionToggle) {
        reduceMotionToggle.addEventListener('change', function() {
            if (this.checked) {
                document.body.classList.add('reduce-motion');
                saveUserPreference('reduceMotion', true);
                announceChange('Motion reduced');
            } else {
                document.body.classList.remove('reduce-motion');
                saveUserPreference('reduceMotion', false);
                announceChange('Motion enabled');
            }
        });
    }
    
    // Focus mode toggle
    const focusModeToggle = document.getElementById('focusMode');
    
    if (focusModeToggle) {
        focusModeToggle.addEventListener('change', function() {
            if (this.checked) {
                document.body.classList.add('focus-mode');
                saveUserPreference('focusMode', true);
                announceChange('Focus mode enabled');
            } else {
                document.body.classList.remove('focus-mode');
                saveUserPreference('focusMode', false);
                announceChange('Focus mode disabled');
            }
        });
    }
    
    // Close accessibility panel when clicking outside
    document.addEventListener('click', function(event) {
        if (accessibilityControls.classList.contains('active') && 
            !accessibilityControls.contains(event.target) && 
            event.target !== toggleButton) {
            accessibilityControls.classList.remove('active');
            toggleButton.setAttribute('aria-expanded', 'false');
        }
    });
}

/**
 * Navigation Functionality
 * Handles mobile navigation and dropdown menus
 */
function initNavigation() {
    // Mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            const isExpanded = mainNav.classList.contains('active');
            menuToggle.setAttribute('aria-expanded', isExpanded);
            
            // Change menu icon appearance
            if (isExpanded) {
                menuToggle.classList.add('active');
            } else {
                menuToggle.classList.remove('active');
            }
        });
    }
    
    // Handle dropdown menus for mobile
    const dropdownItems = document.querySelectorAll('.has-dropdown');
    
    dropdownItems.forEach(item => {
        const link = item.querySelector('a');
        
        // For mobile: toggle dropdown visibility on click
        link.addEventListener('click', function(e) {
            // Only handle as dropdown toggle on mobile
            if (window.innerWidth <= 768) {
                e.preventDefault();
                item.classList.toggle('active');
            }
        });
        
        // Ensure keyboard accessibility
        link.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                if (window.innerWidth <= 768) {
                    e.preventDefault();
                    item.classList.toggle('active');
                }
            }
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (window.innerWidth <= 768) {
            if (mainNav.classList.contains('active') && 
                !mainNav.contains(event.target) && 
                event.target !== menuToggle) {
                mainNav.classList.remove('active');
                menuToggle.setAttribute('aria-expanded', 'false');
                menuToggle.classList.remove('active');
            }
        }
    });
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            // Reset mobile menu state when resizing to desktop
            mainNav.classList.remove('active');
            menuToggle.setAttribute('aria-expanded', 'false');
            menuToggle.classList.remove('active');
            
            // Reset all dropdown states
            dropdownItems.forEach(item => {
                item.classList.remove('active');
            });
        }
    });
}

/**
 * Search Functionality
 * Handles the search toggle and search form
 */
function initSearch() {
    const searchToggle = document.querySelector('.search-toggle');
    const searchContainer = document.getElementById('searchContainer');
    const searchClose = document.getElementById('searchClose');
    const searchInput = searchContainer ? searchContainer.querySelector('input[type="search"]') : null;
    
    if (searchToggle && searchContainer && searchClose) {
        // Toggle search container
        searchToggle.addEventListener('click', function() {
            searchContainer.classList.add('active');
            if (searchInput) {
                // Focus on search input after a short delay to ensure it's visible
                setTimeout(() => {
                    searchInput.focus();
                }, 100);
            }
        });
        
        // Close search container
        searchClose.addEventListener('click', function() {
            searchContainer.classList.remove('active');
            searchToggle.focus(); // Return focus to the toggle button
        });
        
        // Close search on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && searchContainer.classList.contains('active')) {
                searchContainer.classList.remove('active');
                searchToggle.focus();
            }
        });
        
        // Handle search form submission
        const searchForm = searchContainer.querySelector('.search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const searchTerm = searchInput.value.trim();
                
                if (searchTerm) {
                    // In a real implementation, this would redirect to search results
                    // For now, we'll just log the search term
                    console.log('Search term:', searchTerm);
                    
                    // Example of how you would redirect to a search results page:
                    // window.location.href = `search-results.html?q=${encodeURIComponent(searchTerm)}`;
                    
                    // Close the search container
                    searchContainer.classList.remove('active');
                }
            });
        }
    }
}

/**
 * Product Interactions
 * Handles product-related interactions like add to cart
 */
function initProductInteractions() {
    // Add to cart buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productName = productCard ? productCard.querySelector('h3').textContent : 'Product';
            
            // Update cart count (this is just a visual demo)
            const cartCount = document.querySelector('.cart-count');
            if (cartCount) {
                const currentCount = parseInt(cartCount.textContent);
                cartCount.textContent = currentCount + 1;
                
                // Add a brief animation to the cart icon
                const cartIcon = document.querySelector('.cart-icon');
                cartIcon.classList.add('cart-updated');
                setTimeout(() => {
                    cartIcon.classList.remove('cart-updated');
                }, 700);
            }
            
            // Show feedback to the user
            showNotification(`${productName} added to cart`);
        });
    });
}

/**
 * User Preferences
 * Save and load user preferences for accessibility settings
 */
function saveUserPreference(key, value) {
    try {
        localStorage.setItem(`neurohive_${key}`, JSON.stringify(value));
    } catch (e) {
        console.error('Failed to save user preference:', e);
    }
}

function loadUserPreferences() {
    try {
        // Font size
        const savedFontSize = localStorage.getItem('neurohive_fontSize');
        if (savedFontSize) {
            document.documentElement.style.fontSize = `${JSON.parse(savedFontSize)}px`;
        }
        
        // Color mode
        const savedColorMode = localStorage.getItem('neurohive_colorMode');
        if (savedColorMode) {
            const colorMode = JSON.parse(savedColorMode);
            if (colorMode === 'dark') {
                document.body.classList.add('dark-mode');
            } else if (colorMode === 'high-contrast') {
                document.body.classList.add('high-contrast');
            }
            
            // Update the toggle state
            const modeButton = document.getElementById(`${colorMode}Mode`);
            if (modeButton) {
                modeButton.setAttribute('aria-pressed', 'true');
            }
        }
        
        // Reduce motion
        const savedReduceMotion = localStorage.getItem('neurohive_reduceMotion');
        if (savedReduceMotion && JSON.parse(savedReduceMotion)) {
            document.body.classList.add('reduce-motion');
            const reduceMotionToggle = document.getElementById('reduceMotion');
            if (reduceMotionToggle) {
                reduceMotionToggle.checked = true;
            }
        }
        
        // Focus mode
        const savedFocusMode = localStorage.getItem('neurohive_focusMode');
        if (savedFocusMode && JSON.parse(savedFocusMode)) {
            document.body.classList.add('focus-mode');
            const focusModeToggle = document.getElementById('focusMode');
            if (focusModeToggle) {
                focusModeToggle.checked = true;
            }
        }
    } catch (e) {
        console.error('Failed to load user preferences:', e);
    }
}

/**
 * Utility Functions
 */

// Show notification to the user
function showNotification(message, type = 'success') {
    // Create notification element if it doesn't exist
    let notification = document.querySelector('.notification');
    
    if (!notification) {
        notification = document.createElement('div');
        notification.className = 'notification';
        document.body.appendChild(notification);
    }
    
    // Set notification content and type
    notification.textContent = message;
    notification.className = `notification ${type}`;
    
    // Show the notification
    notification.classList.add('active');
    
    // Hide after a delay
    setTimeout(() => {
        notification.classList.remove('active');
    }, 3000);
}

// Announce changes to screen readers
function announceChange(message) {
    // Create or get the live region
    let liveRegion = document.getElementById('a11y-announcer');
    
    if (!liveRegion) {
        liveRegion = document.createElement('div');
        liveRegion.id = 'a11y-announcer';
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.className = 'visually-hidden';
        document.body.appendChild(liveRegion);
    }
    
    // Set the message
    liveRegion.textContent = message;
    
    // Clear after a delay
    setTimeout(() => {
        liveRegion.textContent = '';
    }, 3000);
}

// Add CSS for notifications and animations that are added by JS
(function addDynamicStyles() {
    const style = document.createElement('style');
    style.textContent = `
        /* Notification */
        .notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 12px 20px;
            background-color: var(--success, #4caf50);
            color: white;
            border-radius: var(--radius-md, 8px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transform: translateY(100px);
            opacity: 0;
            transition: transform 0.3s ease, opacity 0.3s ease;
            z-index: 1000;
            max-width: 300px;
        }
        
        .notification.active {
            transform: translateY(0);
            opacity: 1;
        }
        
        .notification.error {
            background-color: var(--error, #d64045);
        }
        
        /* Cart animation */
        .cart-updated {
            animation: pulse 0.7s ease;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
        
        /* Screen reader only */
        .visually-hidden {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
    `;
    document.head.appendChild(style);
})();